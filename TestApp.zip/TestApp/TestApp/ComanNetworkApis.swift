//
//  ComanNetworkApis.swift
//  iCreate
//
//  Created by Mahathi Software on 24/04/19.
//  Copyright © 2019 Nicklaus Health. All rights reserved.
//
import Foundation

enum Methode:String {
    case GET = "GET"
    case POST = "POST"
   
}
class ComanNetworkApis {
    class func makeAPicall(urlextension:String,parameters:[String:Any],methode:Methode,success:@escaping (Data)->Void, failure:@escaping (String)->Void) {
        //let baseurl = URLConfigurationManager.sharedInstance.baseUrl()
        guard let url = URL(string: urlextension) else {
            
            return
        }
        
        var tokenString:String = "Bearer "
            
        if(UserDefaults.standard.string(forKey: "AcessTokenSet") != nil)
        {
            tokenString += UserDefaults.standard.string(forKey: "AcessTokenSet")!
        }
        
        var request : URLRequest = URLRequest(url: url)
        
        if methode == .POST  {
            
            let headers = [
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": "\(tokenString)",
                "cache-control": "no-cache",
                "Postman-Token": "55ab4a19-cde9-46e6-b3bb-18c1654701cc"
            ]
            
            let idset : String = UserDefaults.standard.string(forKey: "IDSet") as! String
            
            let postData = NSMutableData(data: "id=\(idset)".data(using: String.Encoding.utf8)!)
            postData.append("&undefined=undefined".data(using: String.Encoding.utf8)!)
            
            
            let data = try! JSONSerialization.data(withJSONObject:parameters, options: .prettyPrinted)
            
            request.httpMethod = "POST"
            request.allHTTPHeaderFields = headers
            request.httpBody = postData as Data
            
            
        }
        else
        {
            request.httpMethod = methode.rawValue
            if(UserDefaults.standard.string(forKey: "AcessTokenSet") != nil) {
                print(UserDefaults.standard.string(forKey: "AcessTokenSet")!)
            }
            request.setValue(tokenString, forHTTPHeaderField: "Authorization")
        }
        
        let session = URLSession.shared
        

        let task = session.dataTask(with: request, completionHandler: {
            (data, response, error) in
            
            if let data1 = data {
                do {
                    // Convert the data to JSON
                    var jsonSerialized = try JSONSerialization.jsonObject(with: data1, options: []) as? [String : Any]
                }
                catch let error as NSError {
                    print(error.localizedDescription)
                    return
                }
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                
                print("error \(httpResponse.statusCode)")
                if httpResponse.statusCode == 200 || httpResponse.statusCode == 201
                {
                    
                    
                 
                    DispatchQueue.main.async { // Correct
                        
                        guard let responseData = data else {
                            print("Error: did not receive data")
                            failure("Error: did not receive data")
                            return
                        }
                        success(responseData)
                        print(responseData)
                    }
                    
                }
        
                else
                {
                    failure("Error: did not receive data")
                }
            }
        })
        task.resume()
        
        
    }
   
}

