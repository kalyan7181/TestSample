//
//  NewsFeedViewController.swift
//  TestApp
//
//  Created by Mahathi Software on 05/08/19.
//  Copyright © 2019 Mahathi Software. All rights reserved.
//

import UIKit
import SDWebImage
struct NewsFeedResult : Codable {
    let kstream: Kstream
}
struct Kstream: Codable {
    let data: [Datum]
    
}
struct Datum: Codable {

    let title: String?
    let fullDescription: String
    let titleImageURL: String?
    let descriptionImageURL: String
    let articleURL: String
    let likes, shares: Int

    enum CodingKeys: String, CodingKey {
        case title = "title"
        case fullDescription = "full_description"
        case titleImageURL = "title_image_url"
        case descriptionImageURL = "description_image_url"
        case articleURL = "article_url"
        case likes, shares
    }
}
class NewsFeedViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var newsTableview: UITableView!
    var title1:[String] = []
    var titleimag1:[String] = []
    var description1:[String] = []
    var descriptionimg1:[String] = []
    var articleurlString:[String] = []
    var like1:[Int] = []
    var share1:[Int] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        newsTableview.delegate = self
        newsTableview.dataSource = self
      newsTableview.isHidden = true
        self.newsfeedCall()
   
    }
    
    @IBAction func logoutclicked(_ sender: Any) {
         navigationController?.popViewController(animated: false)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return title1.count
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
            return 350
       
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsFeedCell", for: indexPath) as! NewsFeedCell
        cell.titleLabel.text = title1 [indexPath.row]
        cell.descriptionLabel.text = description1 [indexPath.row]
        cell.likeslabel.text = "\(String(like1 [indexPath.row])) Likes"
        cell.sharesLabel.text = "\(String(share1 [indexPath.row])) Shares"
        
//        let imageURL = URL(string: "https://upload.wikimedia.org/wikipedia/commons/1/15/Red_Apple.jpg")!
//        cell.descriptionImageUrl.sd_setShowActivityIndicatorView(true)
//        cell.descriptionImageUrl.sd_setIndicatorStyle(.gray)
//        cell.descriptionImageUrl.sd_setImage(with: imageURL)
        
        let url1 : String = titleimag1 [indexPath.row]
        let imageExtensions = ["png", "jpg", "gif"]
        // Iterate & match the URL objects from your checking results
        let url: URL? = NSURL(fileURLWithPath: url1) as URL
        let pathExtention = url?.pathExtension
        if imageExtensions.contains(pathExtention!)
        {
            let url1 : String = titleimag1 [indexPath.row]
            cell.NewsImage.sd_setImage(with: URL(string:url1), placeholderImage: UIImage(named: "No_Profile.png"))
       
        }
        
        let url2 : String = descriptionimg1 [indexPath.row]
        let imageExtensions1 = ["png", "jpg", "gif"]
        // Iterate & match the URL objects from your checking results
        let url3: URL? = NSURL(fileURLWithPath: url2) as URL
        let pathExtention2 = url3?.pathExtension
        if imageExtensions1.contains(pathExtention2!)
        {

            let url6 : String = descriptionimg1 [indexPath.row]
            cell.descriptionImageUrl.sd_setImage(with: URL(string:url6), placeholderImage: UIImage(named: "default-image.png"))

        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        DispatchQueue.main.async {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "NewsFeedWebStory") as! NewsFeedWebViewController
            viewController.articleurl = self.articleurlString[indexPath.row]
            self.navigationController?.pushViewController(viewController, animated: false)
            print("Success")
            
        }
    }
    @IBAction func backClicked(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    func newsfeedCall() {
       
        let url = URL(string: "https://gospark.app/api/v1/kstream")!
      
        var request : URLRequest = URLRequest(url: url)
        request.httpMethod = "GET"
        let tokenString = "Bearer " + UserDefaults.standard.string(forKey: "AcessTokenSet")!
        print(UserDefaults.standard.string(forKey: "AcessTokenSet")!)
        request.setValue(tokenString, forHTTPHeaderField: "Authorization")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        // make the request
        let task = session.dataTask(with: request, completionHandler: {
            (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("error \(httpResponse.statusCode)")
                if httpResponse.statusCode == 200 || httpResponse.statusCode == 201
                {
                    DispatchQueue.main.async { // Correct
                        
                        guard let responseData = data else {
                            print("Error: did not receive data")
                            return
                        }
                        do {
       
                            let Models = try! JSONDecoder().decode(NewsFeedResult.self, from: responseData)
                            print(Models)
                            for business in Models.kstream.data
                            {
                               
                                    self.title1.append(business.title!)
                                if business.titleImageURL == nil{
                                    
                                    self.titleimag1.append("nil")
                                    }
                                    else
                                    {
                                    
                                    self.titleimag1.append(business.titleImageURL!)
                                    
                                }
                                
                                    self.description1.append(business.fullDescription)
                                    self.descriptionimg1.append(business.descriptionImageURL)
                                    self.articleurlString.append(business.articleURL)
                                    self.like1.append(business.likes)
                                    self.share1.append(business.shares)
                               
                            }
                             self.newsTableview.isHidden = false
                            self.newsTableview.reloadData()
  
                            }
                          
                        }
                      
                    }
                    
                }
             
                else
                {
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert!", message:
                            "No data found", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                        
                        self.present(alertController, animated: true, completion: nil)
                     
                    }
                }
            //}
        })
        task.resume()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
