//
//  RegisterViewController.swift
//  TestApp
//
//  Created by Mahathi Software on 05/08/19.
//  Copyright © 2019 Mahathi Software. All rights reserved.
//

import UIKit
import Toaster
struct RegisterResult: Codable {
    
}
class RegisterViewController: UIViewController {
    @IBOutlet weak var nameTextfiled: UITextField!
    @IBOutlet weak var emailTextfiled: UITextField!
    @IBOutlet weak var passwordTextfiled: UITextField!
    @IBOutlet weak var passwordConfirmationTextfiled: UITextField!
    @IBOutlet weak var mobileTextfiled: UITextField!
    @IBOutlet weak var genderTextfiled: UITextField!
     var myView : SpinnerView?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        nameTextfiled.text = "Phaneendra Hari"
//        emailTextfiled.text = "hari2@spotflock.com"
//        passwordTextfiled.text = "akjshdlaks"
//        passwordConfirmationTextfiled.text = "akjshdlaks"
//        mobileTextfiled.text = "9959277190"
//        genderTextfiled.text = "Male"
        
        myView = SpinnerView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
        myView!.center = self.view.center
        self.view.addSubview(myView!)
        myView!.isHidden = true
    }
    
    @IBAction func backClicked(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    @IBAction func submitClicked(_ sender: Any) {
        if nameTextfiled.text == "" || emailTextfiled.text == "" || passwordTextfiled.text == "" || passwordConfirmationTextfiled.text == "" || mobileTextfiled.text == "" || genderTextfiled.text == ""
        {
            
            Toast(text: "Fill all the fields and try again").show()
            ToastView.appearance() .font = UIFont (name: "Helvetica Neue", size: 19)
            
        }
        else if(passwordTextfiled.text != passwordConfirmationTextfiled.text)
        {
            
            Toast(text: "Confirm password not mactched with password.Please try again").show()
            ToastView.appearance() .font = UIFont (name: "Helvetica Neue", size: 19)
        }
        else
        {
        self.RegsiterCall()
        }
    }
    func RegsiterCall() {
        myView!.isHidden = false
        let url = URL(string: "https://gospark.app/api/v1/register")!
        let postString = [
            "name": nameTextfiled.text!,
            "email": emailTextfiled.text!,
            "password": passwordTextfiled.text!,
            "password_confirmation": passwordConfirmationTextfiled.text!,
            "mobile": mobileTextfiled.text!,
            "gender": genderTextfiled.text!,
            ] as [String : Any]
        
        print("poststring: \(postString)")
        let jsonData = try! JSONSerialization.data(withJSONObject: postString, options: [])
        
        var request : URLRequest = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField:"Content-Type")
        request.httpBody = jsonData
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        // make the request
        let task = session.dataTask(with: request, completionHandler: {
            (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("error \(httpResponse.statusCode)")
                if httpResponse.statusCode == 200 || httpResponse.statusCode == 201
                {
                    DispatchQueue.main.async {
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let viewController = storyboard.instantiateViewController(withIdentifier: "ViewControllerStory") as! ViewController
                       
                        self.navigationController?.pushViewController(viewController, animated: false)
                       print("Success")
                         self.myView!.isHidden = true
                        
                    }
                }
                else
                {
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert!", message:
                            "Try Again", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                        
                        self.present(alertController, animated: true, completion: nil)
                        
                    }
                }
            }
        })
        task.resume()
        
    }
}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
