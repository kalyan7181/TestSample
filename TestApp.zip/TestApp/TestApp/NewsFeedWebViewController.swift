//
//  NewsFeedWebViewController.swift
//  TestApp
//
//  Created by Mahathi Software on 06/08/19.
//  Copyright © 2019 Mahathi Software. All rights reserved.
//

import UIKit
import WebKit
class NewsFeedWebViewController: UIViewController, WKNavigationDelegate {
    @IBOutlet weak var Activity: UIActivityIndicatorView!
    var articleurl:String?
    var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.webView = WKWebView(frame: CGRect( x: 0, y: 75, width: self.view.frame.width - 8, height: self.view.frame.height), configuration: WKWebViewConfiguration() )
        webView.scrollView.contentInset = UIEdgeInsets(top: 8, left: 8,bottom: 80, right: 0)
        self.view.addSubview(self.webView)
        self.newsfeedWebCall()
       
    }
    func newsfeedWebCall() {
        let activityView = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.white)
        activityView.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityView.startAnimating()
        let url = URL(string: articleurl!)
        var request : URLRequest = URLRequest(url: url!)
        request.httpMethod = "GET"
        let tokenString = "Bearer " + UserDefaults.standard.string(forKey: "AcessTokenSet")!
        print(UserDefaults.standard.string(forKey: "AcessTokenSet")!)
        request.setValue(tokenString, forHTTPHeaderField: "Authorization")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        // make the request
        let task = session.dataTask(with: request, completionHandler: {
            (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("error \(httpResponse.statusCode)")
                if httpResponse.statusCode == 200 || httpResponse.statusCode == 201
                {
                    
                    
                    DispatchQueue.main.async { // Correct
                        
                        guard let responseData = data else {
                            print("Error: did not receive data")
                            return
                        }
                        print(String(data: responseData, encoding: .utf8) as Any)
                        let description = String(data: responseData, encoding: .utf8)!
                        var headerString = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'></header>"
                        headerString.append(description)
                        self.webView.loadHTMLString("\(headerString)", baseURL: nil)
                 
                    }
                }
               
                else
                {
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "iCreate", message:
                            "Try Again", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                        
                        self.present(alertController, animated: true, completion: nil)
                        
                    }
                }
            }
        })
        task.resume()
    }
    @IBAction func backClicked(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Activity.stopAnimating()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        Activity.stopAnimating()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
