//
//  ViewController.swift
//  TestApp
//
//  Created by Mahathi Software on 05/08/19.
//  Copyright © 2019 Mahathi Software. All rights reserved.
//

import UIKit
struct LoginResult: Codable {
    let user: User?
}
struct User: Codable {

    let api_token: String?
    enum CodingKeys: String, CodingKey {
        case api_token = "api_token"
    }
}
class ViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    var myView : SpinnerView?
    var Api_TokenString:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
        emailTextField.text = "hari2@spotflock.com"
        passwordTextField.text = "akjshdlaks"
        myView = SpinnerView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
        myView!.center = self.view.center
        self.view.addSubview(myView!)
        myView!.isHidden = true
    }
    
    @IBAction func loginClicked(_ sender: Any) {
     self.loginCall()
        
    }
    @IBAction func registerClicked(_ sender: Any) {
        DispatchQueue.main.async {
            let viewController = self.storyboard?.instantiateViewController(withIdentifier:"RegisterViewStoryboard")
            
            self.navigationController?.pushViewController(viewController!, animated: false)
            print("Success")
            
        }
    }
    func loginCall() {
        myView!.isHidden = false
        let url = URL(string: "https://gospark.app/api/v1/login")!
        let postString = [
            "email": emailTextField.text!,
            "password": passwordTextField.text!
            ] as [String : Any]
        print("poststring: \(postString)")
        let jsonData = try! JSONSerialization.data(withJSONObject: postString, options: [])
        
        var request : URLRequest = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField:"Content-Type")
        request.httpBody = jsonData
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        // make the request
        let task = session.dataTask(with: request, completionHandler: {
            (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("error \(httpResponse.statusCode)")
                if httpResponse.statusCode == 200 || httpResponse.statusCode == 201
                {
                    DispatchQueue.main.async { // Correct
                        
                        guard let responseData = data else {
                            print("Error: did not receive data")
                            return
                        }
                        
                        let decoder = JSONDecoder()
                        // print(String(data: responseData, encoding: .utf8))
                        do {
                            
                            let sentPost = try decoder.decode(LoginResult.self, from: responseData)
                            print(sentPost)
                            // save access token
                            UserDefaults.standard.set(sentPost.user?.api_token!, forKey: "AcessTokenSet")
                            DispatchQueue.main.async {
                                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                let viewController = storyboard.instantiateViewController(withIdentifier: "NewsFeedStory") as! NewsFeedViewController
                                
                                self.navigationController?.pushViewController(viewController, animated: false)
                                print("Success")
                                 self.myView!.isHidden = true
                                
                            }
                            
                        } catch {
                           
                            DispatchQueue.main.async {

                                let errMsg: String = "Could not authenticate, exception caught. Please try again later."
                                let alertController = UIAlertController(title: "Alert!", message:
                                    errMsg, preferredStyle: .alert)
                                alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                                
                                self.present(alertController, animated: true, completion: nil)
                             
                                
                            }
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert!", message:
                            "Try Again", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                        
                        self.present(alertController, animated: true, completion: nil)
                      
                    }
                }
            }
        })
        task.resume()

    }
}

